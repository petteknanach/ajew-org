#!/usr/bin/env python3
"""Source-backed STUDY representation, never a StamAshkenaz overlay.
Keep the fully associated Unicode/shaping in all four modes. Hide only original
mark contours in three named presentation fonts. No metrics/anchors are changed.
Requires fontTools and uharfbuzz. Run with isolated website and evidence paths.
"""
import argparse, base64, copy, hashlib, json, math, re, urllib.request
from pathlib import Path
from fontTools.ttLib import TTFont
from fontTools.ttLib.tables._g_l_y_f import Glyph
import uharfbuzz as hb
ROOT = Path(__file__).resolve().parents[1]
a = argparse.ArgumentParser(); a.add_argument('site', type=Path); a.add_argument('out', type=Path); a.add_argument('--offline', action='store_true'); args = a.parse_args()
out=args.out; out.mkdir(parents=True,exist_ok=True)
source=ROOT/'assets/fonts/ShlomoStam.ttf'; raw=source.read_bytes(); orig=TTFont(source,recalcTimestamp=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
base='https://raw.githubusercontent.com/aharonium/fonts/master/Fonts/Hebrew%20Letters%20with%20Vowels%20and%20Cantillation/Shlomo%20Orbach%20(OFL)/'
upstream=(ROOT/'assets/fonts/study-stam/ShlomoStam-source.ttf').read_bytes() if args.offline else urllib.request.urlopen(base+'ShlomoStam.ttf').read(); assert upstream==raw,'bundled source differs from author distribution'
readme=(ROOT/'assets/fonts/study-stam/AUTHOR-README.htm').read_bytes() if args.offline else urllib.request.urlopen(base+'README.htm').read()
assert b'Open Font License' in readme
notice=ROOT/'assets/fonts/study-stam';notice.mkdir(exist_ok=True)
(notice/'AUTHOR-README.htm').write_bytes(readme)
(notice/'ShlomoStam-source.ttf').write_bytes(raw)
(notice/'LICENSE.txt').write_bytes((ROOT/'assets/fonts/ShlomoStam-LICENSE.txt').read_bytes())
# Semantic identities come ONLY from cmap and original composite components.
# Mixed vowel+meteg simple ligatures are separated by exact contour identity.
names=orig.getGlyphOrder(); cmap=orig.getBestCmap(); classes={}
for cp,g in cmap.items():
 if 0x591<=cp<=0x5af or cp in (0x5bd,0x5c0): classes[g]='taamim'
 elif 0x5b0<=cp<=0x5bc or cp in (0x5bf,0x5c1,0x5c2,0x5c7): classes[g]='nikud'
 elif cp in (0x5c4,0x5c5,0x5c6) or 0x5d0<=cp<=0x5ea: classes[g]='source'
# These author-provided alternate marks have explicit component ancestry.
classes.update({'metegright':'taamim','metegleft':'taamim','varika':'nikud'})
def contours(g):
 x=orig['glyf'][g];coords,ends,flags=x.getCoordinates(orig['glyf']); starts=[0]+[e+1 for e in ends[:-1]]
 return [(list(coords[s:e+1]),list(flags[s:e+1])) for s,e in zip(starts,ends)]
def signature(c):
 coords,flags=c; minx=min(x for x,y in coords);miny=min(y for x,y in coords)
 return (tuple((x-minx,y-miny) for x,y in coords),tuple(flags))
mixed={}
for g in ('hatafsegolmeteg','hatafpatahmeteg','hatafqamatsmeteg'):
 cs=contours(g)
 # The author's mixed ligatures use a thinner (117 vs 167 units) meteg:
 # same original top/bottom -154/-649, four on-curve rectangle points.
 # Select the unique SOURCE contour, not a new/translated donor outline.
 match=[i for i,(pts,flags) in enumerate(cs) if len(pts)==4 and flags==[1]*4 and
        sorted(set(y for x,y in pts))==[-649,-154] and max(x for x,y in pts)-min(x for x,y in pts)==117]
 assert len(match)==1,(g,'authored meteg contour not unambiguously identified')
 mixed[g]=match[0]
def filtered(g,keep_n,keep_t,cache):
 if g in cache:return copy.deepcopy(cache[g])
 old=orig['glyf'][g];kind=classes.get(g)
 if (kind=='nikud' and not keep_n) or (kind=='taamim' and not keep_t): new=Glyph();new.numberOfContours=0
 elif kind=='source':new=copy.deepcopy(old)
 elif g in mixed:
  cs=contours(g); chosen=[c for i,c in enumerate(cs) if (keep_t if i==mixed[g] else keep_n)]
  if len(chosen)==len(cs):new=copy.deepcopy(old)
  elif not chosen:new=Glyph();new.numberOfContours=0
  else:
   from fontTools.ttLib.tables._g_l_y_f import GlyphCoordinates
   from array import array
   new=copy.deepcopy(old);new.coordinates=GlyphCoordinates();new.flags=array('B');new.endPtsOfContours=[]
   for coords,flags in chosen:
    new.coordinates.extend(coords);new.flags.extend(flags);new.endPtsOfContours.append(len(new.coordinates)-1)
   new.numberOfContours=len(chosen);new.program.fromBytecode([])
 elif old.isComposite():
  new=copy.deepcopy(old)
  # Preserve component positions exactly. Removing a source mark's outline
  # happens in its own glyph; composites then inherit it without re-anchoring.
  for c in old.components:filtered(c.glyphName,keep_n,keep_t,cache)
 else:new=copy.deepcopy(old)
 cache[g]=new;return copy.deepcopy(new)
packed={}; modes={}
reference=TTFont(source,recalcTimestamp=False,recalcBBoxes=False);reference['glyf'].removeHinting()
for mode,kn,kt in [('full',True,True),('nikud',True,False),('taamim',False,True),('bare',False,False)]:
 f=TTFont(source,recalcTimestamp=False,recalcBBoxes=False);cache={}
 for g in names: filtered(g,kn,kt,cache)
 for g,new in cache.items():f['glyf'][g]=new
 # Composite hint instructions depend on removed mark point indices. Disable
 # hints CONSISTENTLY in all four study faces so their consonant pixels, not
 # merely their contours and advances, remain identical across mark toggles.
 # Original full source font is preserved separately, unchanged.
 f['glyf'].removeHinting()
 for tag in ('fpgm','prep','cvt '):
  if tag in f:del f[tag]
 family='Ajew Study Stam '+mode.title()
 for n in f['name'].names:
  if n.nameID in (1,2,3,4,6,16,17):
   val='Regular' if n.nameID in (2,17) else family.replace(' ','') if n.nameID==6 else family
   n.string=val.encode(n.getEncoding())
 target=notice/('AjewStudyStam-'+mode+'.ttf');f.save(target);data=target.read_bytes()
 # SHAPING TABLES AND ADVANCES MUST BE BYTE-IDENTICAL.
 derived=TTFont(target,recalcTimestamp=False)
 for tag in ('GPOS','GSUB','GDEF','hmtx','hhea'):assert orig.getTableData(tag)==derived.getTableData(tag),(mode,tag)
 assert orig.getBestCmap()==derived.getBestCmap()
 assert orig.reader['cmap']==derived.reader['cmap']
 for cp,g in cmap.items():
  if 0x5d0<=cp<=0x5ea or cp in (0x5c4,0x5c5,0x5c6):
   assert reference['glyf'][g].compile(reference['glyf'])==derived['glyf'][g].compile(derived['glyf']),(mode,g)
 packed[mode]=base64.b64encode(data).decode();modes[mode]=data
# Exhaustive shaping conservation on every unique associated word, all modes.
def shape(data,text):
 font=hb.Font(hb.Face(data));font.scale=(orig['head'].unitsPerEm,)*2
 b=hb.Buffer();b.add_str(text);b.direction='rtl';b.script='Hebr';b.language='he';hb.shape(font,b)
 return [(i.codepoint,i.cluster,p.x_advance,p.y_advance,p.x_offset,p.y_offset) for i,p in zip(b.glyph_infos,b.glyph_positions)]
pointing=json.loads((ROOT/'assets/data/tikun-fixed/column-pointing.json').read_text());fixed=json.loads((ROOT/'assets/data/tikun-fixed/fixed-columns.json').read_text())
texts={t[2] for ls in pointing['columns'].values() for ts in ls.values() for t in ts if len(t)==3}
for mode,data in modes.items():
 for text in texts:assert shape(raw,text)==shape(data,text),(mode,text)
# Natural, uniform font size. No horizontal glyph stretching. Each study column
# gets sufficient em width for its longest physical source row in this font.
upem=orig['head'].unitsPerEm
widths={}; extremal={}
for n,ls in fixed['pages'].items():
 longest=0
 for row,line in enumerate(ls,1):
  groups=[]
  for gi,group in enumerate(line['g']):
   fragments=[]
   for si,s in enumerate(group):
    ts=pointing['columns'][n].get(f'{row}:{gi}:{si}',[])
    # Width includes small source-letter size effects and all pointing. Reserve
    # half an em of extra word space plus bleed for every fragment boundary.
    words=[t[2] if len(t)==3 else t[0] for t in ts]
    fragments.append(sum(sum(x[2] for x in shape(raw,t))/upem for t in words)+max(0,len(words)-1)*.5+.8)
   groups.append(sum(fragments)+max(0,len(group)-1)*2)
  width=sum(groups)+max(0,len(groups)-1)*3
  # Large source initial may exceed natural word advance.
  for special in (line.get('L') or {}).values():
   if any(x[1]=='lg' for x in special):width+=.6
  if width>longest:longest=width;extremal[n]=row
 widths[n]=round(max(21,longest+1),3)
# Optional special-nikud alternates in the SAME study face. Keep the four
# unmarked fonts independently selectable; bare/taamim never show vowel ink.
import importlib.util
spec=importlib.util.spec_from_file_location('vowel_builder',ROOT/'scripts/build-tikun-vowel-font.py')
assert spec is not None and spec.loader is not None
vowels=importlib.util.module_from_spec(spec);spec.loader.exec_module(vowels)
annotated={}
for theme in vowels.PALETTES:
 annotated[theme]={}
 for mode in ('full','nikud'):
  data=vowels.make_font(theme,notice/('AjewStudyStam-'+mode+'.ttf'))
  (notice/('AjewStudyMarked-'+mode+'-'+theme+'.ttf')).write_bytes(data)
  annotated[theme][mode]=base64.b64encode(data).decode()
(ROOT/'services/tikunStudyFonts.json').write_text(json.dumps({'fonts':packed,'columnUnits':widths,'annotated':annotated},separators=(',',':'))+'\n')
# Website uses real font files, not base64 over network.
dest=args.site/'public/fonts/tikkun/study-stam';dest.mkdir(parents=True,exist_ok=True)
for p in notice.iterdir(): (dest/p.name).write_bytes(p.read_bytes())
# Original source TTF is also distributed separately, byte-for-byte.
(args.site/'public/tikkun').mkdir(parents=True,exist_ok=True)
(args.site/'public/tikkun/study-geometry.json').write_text(json.dumps(widths,separators=(',',':'))+'\n')
report={'sourceSha256':sha(raw),'upstreamByteIdentical':True,'sourceURL':base+'ShlomoStam.ttf','authorNoticeURL':base+'README.htm','shapedUniqueWords':len(texts),'modes':{k:sha(v) for k,v in modes.items()},'conservedTables':['GPOS','GSUB','GDEF','hmtx','cmap','hhea'],'consonantOutlines':'coordinates and components identical; hinting consistently disabled in ALL four study faces','mixedMetegContours':mixed,'columnUnits':widths,'extremalRows':extremal,'scope':'Additional pointable Shlomo study representation; original fixed ink NOT replaced'}
(out/'study-font-proof.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('columnUnits','extremalRows')},ensure_ascii=False))
