Font bundle output directory. Run the complete builder from this archive root.
