Ajew Study Stam / Ajew Study Marked corresponding source
Original author outlines and full OFL notice remain unmodified in this archive.
The pointable study face is distinct from the fixed original scroll ink.
Unmarked full/nikud/taamim/bare use the same source glyph metrics/anchors.
Marked full/nikud add only isolated COLR alternate paint: two source-centered
bold sheva dots; qatan capital-T topbar with a long thick downward-only stem.
Other marks and consonant outlines remain unchanged. Classifications are NOT
inferred by the font; the source-exact reader selects features from annotations.

Install Python fonttools==4.60.1 uharfbuzz, then reproduce OFFLINE:
  python scripts/build-tikun-study-fonts.py site-output proof-output --offline
Compare outputs to SOURCE-MANIFEST.json. The fixed/pointing data is included
solely to reproduce the geometry proof. No network or release build is needed.
