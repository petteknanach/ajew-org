Tikun Vowels: font source and exact transformation

This archive includes the unmodified Taamey Frank CLM font, its editable
FontForge SFD source, the inherited font license and embedding exception,
and the complete Python transformation for the three displayed palettes.
No consonant outlines or positions are deliberately changed by that recipe.

Extract into an empty directory. With Python 3 and fontTools 4.63.0 installed,
run: python3 scripts/build-tikkun-vowel-font.py
The three outputs are public/fonts/tikkun/TikunVowels-{day,sepia,night}.ttf.
Compare their SHA-256 digests with SOURCE-MANIFEST.json. The SFD is supplied
as editable upstream source; the exact reproduction recipe uses the supplied
upstream TTF to preserve its original compiled OpenType tables.

The source archive is a companion to the served fonts, not a change to Torah
text or to the frozen linguistic classification engine.
