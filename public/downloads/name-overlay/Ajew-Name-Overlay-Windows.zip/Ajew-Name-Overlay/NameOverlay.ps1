# SPDX-License-Identifier: GPL-2.0-only
[CmdletBinding()]
param(
    [switch]$SelfTest,
    [Alias('QaMode')][switch]$Qa,
    [string]$EvidenceDirectory = ''
)
$ErrorActionPreference = 'Stop'
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $EvidenceDirectory) { $EvidenceDirectory = Join-Path $scriptRoot ('qa\run-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + $PID) }
if ([Threading.Thread]::CurrentThread.ApartmentState -ne 'STA') {
    throw 'Run with Windows PowerShell -NoProfile -STA -File NameOverlay.ps1, or use Launch.cmd.'
}
$oldTemp = $env:TEMP
$oldTmp = $env:TMP
$runtime = Join-Path $scriptRoot ('.runtime-' + $PID)
$code = 1
try {
    New-Item -ItemType Directory -Path $runtime -Force | Out-Null
    $env:TEMP = $runtime
    $env:TMP = $runtime
    Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase, System.Xaml, System.Windows.Forms, System.Drawing, System.Web.Extensions
    $references = @(
        'System.dll', 'System.Core.dll',
        [System.Windows.Application].Assembly.Location,
        [System.Windows.Media.Geometry].Assembly.Location,
        [System.Windows.DependencyObject].Assembly.Location,
        [System.Xaml.XamlReader].Assembly.Location,
        [System.Windows.Forms.Screen].Assembly.Location,
        [System.Drawing.Rectangle].Assembly.Location,
        [System.Web.Script.Serialization.JavaScriptSerializer].Assembly.Location
    ) | Select-Object -Unique
    Add-Type -Path (Join-Path $scriptRoot 'NameOverlay.cs') -ReferencedAssemblies $references
    $code = [PortableNameOverlay.Entry]::Run((Join-Path $scriptRoot 'glyphs.json'), [bool]($SelfTest -or $Qa), $EvidenceDirectory)
} catch {
    [Console]::Error.WriteLine($_.Exception.ToString())
    if ($SelfTest -or $Qa) {
        New-Item -ItemType Directory -Path $EvidenceDirectory -Force | Out-Null
        $_ | Out-String | Set-Content -Encoding UTF8 (Join-Path $EvidenceDirectory 'launcher-error.txt')
    }
    $code = 1
} finally {
    $env:TEMP = $oldTemp
    $env:TMP = $oldTmp
    if (Test-Path -LiteralPath $runtime) { Remove-Item -LiteralPath $runtime -Recurse -Force }
}
exit $code
