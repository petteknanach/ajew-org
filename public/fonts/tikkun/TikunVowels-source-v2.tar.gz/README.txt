Tikun Vowels v2 corresponding source

GPL-2 with the original document-embedding exception expressly extended to
these modified versions. Full unmodified upstream notices are included.
The original TTF and editable FontForge SFD are distributed unchanged.

To reproduce from this extracted root, offline after installing dependencies:
  python -m pip install fonttools==4.60.1
  python scripts/build-tikkun-vowel-font.py
The output directory public/fonts/tikkun is already in this archive.
Compare the three outputs to expectedOutputs in SOURCE-MANIFEST.json.

Only COLR paint layers enlarge audible sheva (two separate dots: 1.8x width,
1.4x height) and positive qamats katan (1.5x). Original contours, character
mappings, shaping advances and GPOS anchors remain intact. Non-shaping paint
layer bearings follow their outline bounds to preserve the source origin.
Uncertain qb and meteg do not acquire katan enlargement. No linguistic
classification is inferred or changed by this recipe.
