# Divine Name — portable Windows overlay

## Start and stop

1. Keep every file in this folder together. No installation or administrator account is needed.
2. Double-click **Launch.cmd**. The English control panel opens; **the overlay starts hidden**.
3. Choose a method and press **Show overlay**. Clicks pass through the transparent overlay to ordinary desktop applications beneath it.
4. **Hide now** immediately hides it. **Pause motion** freezes effects without hiding the lettering. Press **Esc** while the control panel is focused to hide it.
5. **Exit**, or close the control panel, to close both owned windows and end the process. **Safe reset** hides the overlay and restores defaults.

If Windows blocks a downloaded script, review these readable source files and your organization's policy. This utility does not remove security protections, request elevation, or change machine/user execution policy. The launcher uses `-ExecutionPolicy Bypass` for its own PowerShell process only; no policy is saved.

## Methods and controls

- **Interleaved:** exact logical sequence `יאהדונהי`, drawn right-to-left using alternating primary and secondary STAM glyph outlines.
- **Nested:** primary `יהוה`, with secondary `אדני` inset inside the final, leftmost `ה`.
- Both methods include the exact centered footer `נַ נַחְ נַחְמָ נַחְמָן מאומן` below the Name. The final word stays unpointed. The footer uses 24 embedded, shaped Keter YG ink outlines (15 letters and 9 vowel marks), never a system-font fallback.
- The footer is much smaller than the Name: its complete ink height, including vowel marks, is exactly **20% of the primary Name ink height** in both methods. It stays centered without being stretched to Name width.
- **Na Nach color:** independent `#RRGGBB` footer color, default black **#000000**. Overall opacity, size and placement apply to Name and footer together; Name effects never affect the footer.
- Primary defaults to sky blue **#87CEEB**; secondary defaults to black **#000000**. Choose presets or type a full `#RRGGBB` color independently for each. Invalid hex is marked red and the last valid color remains active.
- **Opacity:** slider and numeric input both span 0–100%. Zero produces a fully transparent overlay; 100% produces opaque letter interiors. Initial/reset opacity is 80%.
- **Width / height:** independently choose 1–100% of the selected monitor's usable desktop/work area. These define a fitting rectangle: the lettering preserves its original aspect ratio and is never stretched out of proportion.
- **Position:** nine anchors plus Custom X / Y. Custom coordinates are absolute virtual-desktop logical pixels (WPF DIPs); negative values support monitors to the left/above the primary display. Windows rounds to physical device pixels at non-100% display scaling. Monitor choice is based on currently connected monitors. Restart after changing display layout/DPI.
- **Effects:** None, Fire, Glow, Shimmer. Intensity controls the strength. Fire is an animated, slanted heat-gradient fill clipped to the primary STAM outlines, above the selected primary ink with a soft warm halo; it is not a static recoloring or an unbounded particle effect. Glow adds a soft halo. Shimmer moves a gentle luminous sweep across the primary glyphs. The secondary Name retains its own color and geometry for every effect.
- Uncheck **Animate effects** for a static/reduced-motion rendering. Animation runs only while the overlay is visible, motion is enabled, and Fire or Shimmer is selected. Pause/resume is independent of this preference.

Black letters can disappear against a dark desktop. Choose the secondary and footer colors and opacity for your background. The overlay deliberately has no filled background or border and does not intercept clicks, so reposition it with the separate control panel rather than dragging the lettering.

## Scope and safety

This is a local, opt-in devotional display, not a promise of spiritual effects or an authoritative instruction about sacred Names. Treat their display respectfully. No speech, sound, telemetry, network requests, runtime downloads, font installation, persistent preferences, startup registration, scheduled tasks, services, or registry changes are used. The visible control panel is a normal interactive window; only the lettering window is topmost, click-through and non-activating.

Topmost means ordinary Windows desktop windows. Secure desktop/UAC, lock screen, exclusive fullscreen applications, and another application's newer topmost window may hide it. Multi-monitor mixed-DPI/hot-plug layouts and assistive-technology behavior need separate acceptance on the target setup; one native monitor was exercised here.

Required: Windows PowerShell 5.1 in STA mode and the installed .NET Framework/WPF desktop assemblies. There is no SDK or package dependency to install. Readable C# UI code is compiled into the current PowerShell process using the built-in .NET compiler. Temporary compiler files are confined to an owned `.runtime-PID` subfolder and removed on normal completion. An unexpected OS/process termination can leave that small folder; after closing the utility it can be removed.

## Run commands

From this folder in Command Prompt:

```bat
Launch.cmd
Launch.cmd -SelfTest
```

Equivalent explicit command:

```bat
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File ".\NameOverlay.ps1"
```

Finite native QA (no other windows are manipulated):

```bat
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File ".\NameOverlay.ps1" -SelfTest
```

`-QaMode` is an alias for QA mode. You can supply `-EvidenceDirectory "C:\path\to\an\owned\empty\folder"`. The default is a new `qa\run-TIMESTAMP-PID` folder, avoiding overwriting screenshots opened by a viewer. QA opens only its own control/overlay windows without requesting focus, captures native WPF RenderTargetBitmap PNGs, checks actual transparent/opaque/color pixels and native window flags/messages, cycles both methods, placement, opacity and effects, checks animation pixel changes and pause/hide/reset, closes both windows, writes `receipt.json`, prints totals, and exits 0 only if all checks pass. It does not send mouse clicks to other applications. 

## Files and licenses

- `Launch.cmd`: portable launcher.
- `NameOverlay.ps1`: STA bootstrap and local temporary compiler-file cleanup.
- `NameOverlay.cs`: complete readable WPF UI, native styles and finite self-test source. Utility code is distributed under **GPL version 2 only**; see `GNU-GPL`.
- `glyphs.json`: unchanged STAM Ashkenaz CLM Name outlines and reviewed layouts plus shaped Keter YG pointed footer outlines. No font needs installing.
- `LICENSE`, `copyright`, `GNU-GPL`, `FONT-PROVENANCE.json`: upstream font notices, license and pinned provenance. **STAM Ashkenaz is copyright 2007–2010 Yoram Gnat**, GPL version 2 with the explicit font-embedding exception reproduced in `LICENSE`. The original font source is https://github.com/deepin-community/culmus at commit `adb6913d3c9bb6b757d9d85fd92901b3cc9f623e`. No restrictive or unlicensed STAM fonts are included.

All application source is supplied here. No publication, autostart setup or account login is part of this utility.
