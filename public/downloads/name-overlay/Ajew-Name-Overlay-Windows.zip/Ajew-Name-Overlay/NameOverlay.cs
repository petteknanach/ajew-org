// SPDX-License-Identifier: GPL-2.0-only
// Portable Divine Name overlay. All UI and native calls are owned by this process.
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using Path = System.Windows.Shapes.Path;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using Forms = System.Windows.Forms;

namespace PortableNameOverlay {
public static class Entry {
    public static int Run(string glyphFile, bool selfTest, string evidence) {
        var app = new Application();
        app.ShutdownMode = ShutdownMode.OnExplicitShutdown;
        Controller c = null;
        try {
            c = new Controller(app, glyphFile, selfTest, evidence);
            app.Run(c.Panel);
            return c.ExitCode;
        } catch (Exception ex) {
            Console.Error.WriteLine(ex.ToString());
            if (c != null) c.CloseOwned();
            if (selfTest && Directory.Exists(evidence)) File.WriteAllText(System.IO.Path.Combine(evidence,"fatal.txt"), ex.ToString());
            return 1;
        }
    }
}
internal static class Native {
    internal const int EXSTYLE = -20;
    internal const int TRANSPARENT = 0x20, TOOLWINDOW = 0x80, LAYERED = 0x80000, NOACTIVATE = 0x08000000;
    [DllImport("user32.dll", EntryPoint="GetWindowLongW")] internal static extern int GetWindowLong(IntPtr hwnd,int index);
    [DllImport("user32.dll", EntryPoint="SetWindowLongW")] internal static extern int SetWindowLong(IntPtr hwnd,int index,int value);
    [DllImport("user32.dll")] internal static extern bool GetWindowRect(IntPtr hwnd,out RECT rect);
    [DllImport("user32.dll")] internal static extern IntPtr SendMessage(IntPtr hwnd,int msg,IntPtr wp,IntPtr lp);
    [DllImport("user32.dll")] internal static extern bool IsWindowVisible(IntPtr hwnd);
    [DllImport("user32.dll")] internal static extern bool IsWindow(IntPtr hwnd);
    [StructLayout(LayoutKind.Sequential)] internal struct RECT { public int Left,Top,Right,Bottom; }
}
internal sealed class Controller {
    public Window Panel;
    Window overlay;
    Application app;
    Grid root;
    Viewbox view;
    Canvas canvas;
    Path primary, secondary, decoration, footerInk;
    Dictionary<string,object> asset;
    Dictionary<string,object> layout;
    ComboBox method, effect, anchor, monitor;
    ComboBox mainPreset, secondaryPreset;
    TextBox mainHex, secondaryHex, footerHex, opacityNumber, widthNumber, heightNumber, xNumber, yNumber;
    Slider opacitySlider, intensity;
    CheckBox motion;
    Button showButton, pauseButton;
    TextBlock status;
    DispatcherTimer animation, qaTimer;
    bool enabled, paused, updating, closing, qa;
    string evidence;
    double phase;
    int frames;
    IntPtr hwnd;
    LinearGradientBrush animatedBrush;
    Color primaryColor = ParseColor("#87CEEB"), secondaryColor = Colors.Black, footerColor = Colors.Black;
    const string FooterText = "נַ נַחְ נַחְמָ נַחְמָן מאומן";
    double opacity = 0.8, widthPercent = 35, heightPercent = 18, customX = 0, customY = 0;
    readonly List<object> checks = new List<object>();
    int failures, stage;
    byte[] fireBefore, fireAfter;
    int pausedFrames;
    string primaryOrder, secondaryOrder;
    public int ExitCode = 0;

    internal Controller(Application a,string file,bool selfTest,string outdir) {
        app=a; qa=selfTest; evidence=outdir;
        asset = new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(file,Encoding.UTF8));
        overlay = new Window { Title="Divine Name — transparent overlay", WindowStyle=WindowStyle.None,
            ResizeMode=ResizeMode.NoResize, AllowsTransparency=true, Background=Brushes.Transparent,
            Topmost=true, ShowInTaskbar=false, ShowActivated=false, Focusable=false,
            Left=0, Top=0, Width=500, Height=160 };
        root = new Grid { Background=Brushes.Transparent, IsHitTestVisible=false };
        view = new Viewbox { Stretch=Stretch.Uniform, StretchDirection=StretchDirection.Both };
        canvas = new Canvas { IsHitTestVisible=false };
        view.Child=canvas; root.Children.Add(view); overlay.Content=root;
        overlay.SourceInitialized += delegate {
            hwnd=new WindowInteropHelper(overlay).Handle;
            Native.SetWindowLong(hwnd,Native.EXSTYLE,Native.GetWindowLong(hwnd,Native.EXSTYLE) |
                Native.TRANSPARENT|Native.TOOLWINDOW|Native.LAYERED|Native.NOACTIVATE);
            HwndSource.FromHwnd(hwnd).AddHook(Hook);
        };
        BuildPanel();
        animation = new DispatcherTimer(DispatcherPriority.Render);
        animation.Interval=TimeSpan.FromMilliseconds(50);
        animation.Tick += delegate { if (enabled && !paused && motion.IsChecked==true && effect.SelectedIndex>0) { phase+=0.045; frames++; PaintEffect(); } };
        Panel.Closed += delegate { CloseOwned(); app.Shutdown(ExitCode); };
        Panel.PreviewKeyDown += delegate(object sender,System.Windows.Input.KeyEventArgs e) {
            if (e.Key==System.Windows.Input.Key.Escape) { SetEnabled(false); e.Handled=true; }
        };
        Rebuild(); Place();
        if (qa) {
            Directory.CreateDirectory(evidence);
            Panel.ShowActivated=false;
            Panel.Loaded += delegate { StartQa(); };
        }
    }
    IntPtr Hook(IntPtr h,int msg,IntPtr wp,IntPtr lp,ref bool handled) {
        if (msg==0x0084) { handled=true; return new IntPtr(-1); } // HTTRANSPARENT
        if (msg==0x0021) { handled=true; return new IntPtr(3); } // MA_NOACTIVATE
        return IntPtr.Zero;
    }
    static Color ParseColor(string text) {
        if (!Regex.IsMatch(text ?? "", "^#[0-9a-fA-F]{6}$")) throw new FormatException("Use #RRGGBB, for example #87CEEB.");
        return (Color)ColorConverter.ConvertFromString(text);
    }
    static double Num(object value) { return Convert.ToDouble(value,CultureInfo.InvariantCulture); }
    static Dictionary<string,object> Dict(object value) { return (Dictionary<string,object>)value; }
    static object[] Items(object value) {
        var a=value as object[]; if(a!=null)return a;
        return ((ArrayList)value).ToArray();
    }
    void BuildPanel() {
        Panel = new Window { Title="Divine Name • portable controls", Width=490, Height=790,
            MinWidth=440, MinHeight=540, WindowStartupLocation=WindowStartupLocation.CenterScreen,
            Background=new SolidColorBrush(Color.FromRgb(245,247,250)), FontFamily=new FontFamily("Segoe UI"), FontSize=14 };
        var shell=new DockPanel { Margin=new Thickness(20), Background=Panel.Background };
        var heading=new StackPanel();
        heading.Children.Add(new TextBlock { Text="Divine Name", FontSize=26, FontWeight=FontWeights.SemiBold, Foreground=Brushes.MidnightBlue });
        heading.Children.Add(new TextBlock { Text="STAM Ashkenaz • local, transparent, click-through", Margin=new Thickness(0,3,0,14), Foreground=Brushes.DimGray });
        DockPanel.SetDock(heading,Dock.Top); shell.Children.Add(heading);
        var footer=new StackPanel { Margin=new Thickness(0,12,0,0) };
        var buttons=new UniformGrid { Columns=3 };
        showButton=Button("Show overlay",delegate { SetEnabled(!enabled); });
        pauseButton=Button("Pause motion",delegate { SetPaused(!paused); });
        buttons.Children.Add(showButton); buttons.Children.Add(pauseButton);
        buttons.Children.Add(Button("Hide now",delegate { SetEnabled(false); })); footer.Children.Add(buttons);
        var secondRow=new UniformGrid { Columns=2 };
        secondRow.Children.Add(Button("Safe reset",delegate { Reset(); }));
        secondRow.Children.Add(Button("Exit",delegate { Panel.Close(); })); footer.Children.Add(secondRow);
        status=new TextBlock { Text="Hidden. Press Show overlay to opt in.", TextWrapping=TextWrapping.Wrap, Margin=new Thickness(3,9,3,0), Foreground=Brushes.DarkSlateGray };
        footer.Children.Add(status);
        footer.Children.Add(new TextBlock { Text="Esc hides while this panel is focused. Exit or close this panel ends the utility.",TextWrapping=TextWrapping.Wrap,FontSize=12,Foreground=Brushes.DimGray,Margin=new Thickness(3,6,3,0) });
        DockPanel.SetDock(footer,Dock.Bottom);shell.Children.Add(footer);
        var content=new StackPanel();
        method=Combo(new string[]{"Interleaved · alternating Names","Nested · secondary inside final leftmost letter"});
        AddRow(content,"Method",method);
        method.SelectionChanged+=delegate { if(!updating)Rebuild(); };
        mainHex=Text("#87CEEB"); secondaryHex=Text("#000000");
        mainPreset=Combo(new string[]{"Sky blue","Black","White","Gold","Custom"});
        secondaryPreset=Combo(new string[]{"Black","Sky blue","White","Gold","Custom"});
        AddRow(content,"Primary color",ColorRow(mainPreset,mainHex));
        AddRow(content,"Secondary color",ColorRow(secondaryPreset,secondaryHex));
        footerHex=Text("#000000");
        footerHex.ToolTip="Pointed Na Nach footer color (#RRGGBB); independent of Name effects.";
        AddRow(content,"Na Nach color",footerHex);
        footerHex.TextChanged+=delegate { FooterColorChanged(); };
        mainPreset.SelectionChanged+=delegate { Preset(mainPreset,mainHex,true); };
        secondaryPreset.SelectionChanged+=delegate { Preset(secondaryPreset,secondaryHex,false); };
        mainHex.TextChanged+=delegate { ColorChanged(mainHex,true); };
        secondaryHex.TextChanged+=delegate { ColorChanged(secondaryHex,false); };
        opacitySlider=new Slider { Minimum=0,Maximum=100,Value=80,TickFrequency=1,IsSnapToTickEnabled=true, VerticalAlignment=VerticalAlignment.Center, ToolTip="Overlay opacity: 0 to 100 percent" };
        opacityNumber=Text("80"); opacityNumber.Width=64;
        var op=new DockPanel();DockPanel.SetDock(opacityNumber,Dock.Right);op.Children.Add(opacityNumber);op.Children.Add(opacitySlider);
        AddRow(content,"Opacity %",op);
        opacitySlider.ValueChanged+=delegate { if(updating)return; opacity=opacitySlider.Value/100; updating=true;opacityNumber.Text=Math.Round(opacitySlider.Value).ToString(CultureInfo.InvariantCulture);updating=false;root.Opacity=opacity; };
        opacityNumber.TextChanged+=delegate { double v;if(!updating && Valid(opacityNumber,0,100,out v)){opacity=v/100;updating=true;opacitySlider.Value=v;updating=false;root.Opacity=opacity;} };
        widthNumber=Text("35");heightNumber=Text("18");
        AddRow(content,"Width / height %",Pair(widthNumber,heightNumber));
        widthNumber.ToolTip="1–100 percent of the selected monitor work area";heightNumber.ToolTip=widthNumber.ToolTip;
        widthNumber.TextChanged+=delegate { double v;if(!updating && Valid(widthNumber,1,100,out v)){widthPercent=v;Place();} };
        heightNumber.TextChanged+=delegate { double v;if(!updating && Valid(heightNumber,1,100,out v)){heightPercent=v;Place();} };
        monitor=Combo(MonitorNames());AddRow(content,"Monitor",monitor);
        monitor.SelectionChanged+=delegate { if(!updating)Place(); };
        anchor=Combo(new string[]{"Top left","Top center","Top right","Middle left","Center","Middle right","Bottom left","Bottom center","Bottom right","Custom X / Y"});anchor.SelectedIndex=4;
        AddRow(content,"Position",anchor);anchor.SelectionChanged+=delegate { if(!updating)Place(); };
        xNumber=Text("0");yNumber=Text("0");AddRow(content,"Custom X / Y",Pair(xNumber,yNumber));
        xNumber.ToolTip="Screen coordinates in WPF logical pixels (DIPs). Negative values are allowed."; yNumber.ToolTip=xNumber.ToolTip;
        xNumber.TextChanged+=delegate { double v;if(!updating && Valid(xNumber,-100000,100000,out v)){customX=v;if(anchor.SelectedIndex==9)Place();} };
        yNumber.TextChanged+=delegate { double v;if(!updating && Valid(yNumber,-100000,100000,out v)){customY=v;if(anchor.SelectedIndex==9)Place();} };
        effect=Combo(new string[]{"None","Fire","Glow","Shimmer"});AddRow(content,"Effect",effect);
        effect.SelectionChanged+=delegate { if(!updating){PaintEffect();SyncAnimation();} };
        intensity=new Slider {Minimum=0,Maximum=100,Value=55,TickFrequency=5,ToolTip="Effect intensity: 0 to 100 percent"};AddRow(content,"Intensity",intensity);
        intensity.ValueChanged+=delegate { if(!updating)PaintEffect(); };
        motion=new CheckBox {Content="Animate effects (turn off for reduced motion)",IsChecked=true,Margin=new Thickness(0,6,0,6)};
        content.Children.Add(motion);motion.Checked+=delegate {SyncAnimation();};motion.Unchecked+=delegate {SyncAnimation();};
        content.Children.Add(new TextBlock {Text="All three colors remain independent. Effects apply only to the primary STAM Name. The pointed Na Nach footer uses embedded Keter YG outlines. Sizing preserves proportions of both Name and footer.",TextWrapping=TextWrapping.Wrap,Foreground=Brushes.DimGray,FontSize=12,Margin=new Thickness(0,10,0,8)});
        shell.Children.Add(new ScrollViewer {Content=content,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,HorizontalScrollBarVisibility=ScrollBarVisibility.Disabled});
        Panel.Content=shell;
    }
    static Button Button(string label,RoutedEventHandler action) { var b=new Button {Content=label,Padding=new Thickness(8,8,8,8),Margin=new Thickness(3),MinHeight=38};b.Click+=action;return b; }
    static TextBox Text(string text) { return new TextBox {Text=text,Padding=new Thickness(6),VerticalContentAlignment=VerticalAlignment.Center,MinWidth=65}; }
    static ComboBox Combo(string[] labels) {var c=new ComboBox {ItemsSource=labels,SelectedIndex=0,Padding=new Thickness(5),MinHeight=32};return c;}
    static FrameworkElement Pair(FrameworkElement a,FrameworkElement b) {var grid=new Grid();grid.ColumnDefinitions.Add(new ColumnDefinition());grid.ColumnDefinitions.Add(new ColumnDefinition());a.Margin=new Thickness(0,0,4,0);b.Margin=new Thickness(4,0,0,0);Grid.SetColumn(b,1);grid.Children.Add(a);grid.Children.Add(b);return grid;}
    static FrameworkElement ColorRow(ComboBox c,TextBox t){return Pair(c,t);}
    static void AddRow(StackPanel s,string label,FrameworkElement control){var grid=new Grid {Margin=new Thickness(0,0,0,10)};grid.ColumnDefinitions.Add(new ColumnDefinition {Width=new GridLength(132)});grid.ColumnDefinitions.Add(new ColumnDefinition());var l=new TextBlock {Text=label,VerticalAlignment=VerticalAlignment.Center};grid.Children.Add(l);Grid.SetColumn(control,1);grid.Children.Add(control);s.Children.Add(grid);}
    static string[] MonitorNames(){var screens=Forms.Screen.AllScreens;var names=new string[screens.Length];for(int i=0;i<screens.Length;i++)names[i]=(i+1)+" · "+screens[i].DeviceName+(screens[i].Primary?" (primary)":"");return names;}
    bool Valid(TextBox t,double min,double max,out double value){bool ok=double.TryParse(t.Text,NumberStyles.Float,CultureInfo.InvariantCulture,out value)&&!double.IsNaN(value)&&!double.IsInfinity(value)&&value>=min&&value<=max;t.BorderBrush=ok?Brushes.Gray:Brushes.Firebrick;t.ToolTip=ok?null:("Enter a number from "+min+" to "+max+" (decimal point: .)");return ok;}
    void Preset(ComboBox c,TextBox t,bool main){if(updating||c.SelectedIndex==4)return;string label=(string)c.SelectedItem;t.Text=label=="Sky blue"?"#87CEEB":label=="Black"?"#000000":label=="White"?"#FFFFFF":"#FFD166";}
    void ColorChanged(TextBox box,bool main){if(updating)return;try {Color color=ParseColor(box.Text);box.BorderBrush=Brushes.Gray;box.ToolTip=null;if(main)primaryColor=color;else secondaryColor=color;updating=true;(main?mainPreset:secondaryPreset).SelectedIndex=4;updating=false;PaintEffect();}catch(FormatException){box.BorderBrush=Brushes.Firebrick;box.ToolTip="Use a six-digit hex color, such as #87CEEB. Last valid color is retained.";}}
    void FooterColorChanged(){
        if(updating)return;
        try { footerColor=ParseColor(footerHex.Text);footerHex.BorderBrush=Brushes.Gray;footerHex.ToolTip=null;PaintEffect(); }
        catch(FormatException){footerHex.BorderBrush=Brushes.Firebrick;footerHex.ToolTip="Use a six-digit hex color. Last valid footer color is retained.";}
    }
    static Geometry PlacedGeometry(string path,Dictionary<string,object> g,object[] vb){
        var geo=PathGeometry.CreateFromGeometry(Geometry.Parse(path)).Clone();
        var transforms=new TransformGroup();double scale=Num(g["scale"]);
        transforms.Children.Add(new ScaleTransform(scale,-scale));
        transforms.Children.Add(new TranslateTransform(Num(g["x"])-Num(vb[0]),-Num(g["y"])-Num(vb[1])));
        geo.Transform=transforms;return geo;
    }
    void Rebuild(){
        string key=method.SelectedIndex==0?"interleaved":"nested";
        layout=Dict(Dict(asset["layouts"])[key]);object[] vb=Items(layout["viewBox"]);
        canvas.Width=Num(vb[2]);canvas.Height=Num(vb[3]);canvas.Children.Clear();
        var p=new GeometryGroup {FillRule=FillRule.Nonzero};var s=new GeometryGroup {FillRule=FillRule.Nonzero};
        primaryOrder="";secondaryOrder="";
        foreach(object item in Items(layout["glyphs"])){
            var g=Dict(item);string letter=(string)g["letter"];string role=(string)g["role"];
            var geo=PlacedGeometry((string)Dict(Dict(asset["glyphs"])[letter])["path"],g,vb);
            if(role=="primary"){p.Children.Add(geo);primaryOrder+=letter;}else{s.Children.Add(geo);secondaryOrder+=letter;}
        }
        p.Freeze();s.Freeze();
        primary=new Path {Data=p,IsHitTestVisible=false};decoration=new Path {Data=p,IsHitTestVisible=false};secondary=new Path {Data=s,IsHitTestVisible=false};
        canvas.Children.Add(primary);canvas.Children.Add(decoration);canvas.Children.Add(secondary);
        // Use already-shaped embedded ink, including every supplied vowel. No font fallback.
        var f=new GeometryGroup {FillRule=FillRule.Nonzero};
        foreach(object item in Items(layout["footerGlyphs"])){var g=Dict(item);f.Children.Add(PlacedGeometry((string)g["path"],g,vb));}
        f.Freeze();footerInk=new Path {Data=f,IsHitTestVisible=false};canvas.Children.Add(footerInk);
        PaintEffect();root.Opacity=opacity;
    }
    void PaintEffect(){
        if(primary==null || effect==null || intensity==null)return;
        primary.Fill=new SolidColorBrush(primaryColor);secondary.Fill=new SolidColorBrush(secondaryColor);footerInk.Fill=new SolidColorBrush(footerColor);
        primary.Effect=null;decoration.Fill=Brushes.Transparent;animatedBrush=null;decoration.Opacity=0;
        double level=intensity.Value/100;
        if(effect.SelectedIndex==0 || level==0)return;
        if(effect.SelectedIndex==2){primary.Effect=new DropShadowEffect {Color=primaryColor,ShadowDepth=0,BlurRadius=45+level*100,Opacity=level};return;}
        animatedBrush=new LinearGradientBrush();animatedBrush.MappingMode=BrushMappingMode.RelativeToBoundingBox;
        if(effect.SelectedIndex==1){
            // A moving, slanted heat front burns within exact glyph masks. Solid ink below
            // keeps every outline legible; the secondary geometry is never recolored.
            double wave=Math.Sin(phase), wave2=Math.Sin(phase*1.73+0.8);
            animatedBrush.StartPoint=new Point(0.25+0.16*wave2,1.15);
            animatedBrush.EndPoint=new Point(0.65+0.22*wave,-0.12);
            animatedBrush.GradientStops.Add(new GradientStop(Color.FromRgb(150,25,10),0));
            animatedBrush.GradientStops.Add(new GradientStop(Color.FromRgb(255,92,8),0.26+0.055*wave));
            animatedBrush.GradientStops.Add(new GradientStop(Color.FromRgb(255,208,48),0.50+0.08*wave2));
            animatedBrush.GradientStops.Add(new GradientStop(Color.FromArgb(180,255,249,198),0.72+0.045*wave));
            animatedBrush.GradientStops.Add(new GradientStop(Color.FromArgb(0,255,125,16),1));
            decoration.Opacity=0.2+0.65*level;
            primary.Effect=new DropShadowEffect {Color=Color.FromRgb(255,112,20),ShadowDepth=0,BlurRadius=25+level*75,Opacity=0.15+level*0.45};
        }else{
            double center=(Math.Sin(phase*0.65)+1)*0.5;
            animatedBrush.StartPoint=new Point(0,0);animatedBrush.EndPoint=new Point(1,0.15);
            animatedBrush.GradientStops.Add(new GradientStop(Colors.Transparent,Math.Max(0,center-0.24)));
            animatedBrush.GradientStops.Add(new GradientStop(Colors.White,center));
            animatedBrush.GradientStops.Add(new GradientStop(Colors.Transparent,Math.Min(1,center+0.24)));
            decoration.Opacity=level*0.65;
        }
        decoration.Fill=animatedBrush;
    }
    Rect WorkArea(){
        var screens=Forms.Screen.AllScreens;int index=monitor==null?0:Math.Max(0,Math.Min(monitor.SelectedIndex,screens.Length-1));
        var r=screens[index].WorkingArea;
        var source=PresentationSource.FromVisual(overlay);Matrix m=source!=null?source.CompositionTarget.TransformFromDevice:Matrix.Identity;
        Point tl=m.Transform(new Point(r.Left,r.Top)),br=m.Transform(new Point(r.Right,r.Bottom));return new Rect(tl,br);
    }
    void Place(){
        if(anchor==null || monitor==null)return;
        Rect r=WorkArea();double w=r.Width*widthPercent/100,h=r.Height*heightPercent/100;
        overlay.Width=w;overlay.Height=h;
        int pos=anchor.SelectedIndex;
        if(pos==9){overlay.Left=customX;overlay.Top=customY;}else{overlay.Left=r.Left+(r.Width-w)*(pos%3)/2;overlay.Top=r.Top+(r.Height-h)*(pos/3)/2;}
    }
    void SetEnabled(bool value){enabled=value;if(value){overlay.Show();Place();}else overlay.Hide();showButton.Content=enabled?"Hide overlay":"Show overlay";status.Text=enabled?"Visible • clicks pass through to applications below.":"Hidden. The overlay does not intercept clicks.";SyncAnimation();}
    void SetPaused(bool value){paused=value;pauseButton.Content=paused?"Resume motion":"Pause motion";SyncAnimation();}
    void SyncAnimation(){if(animation==null || effect==null || motion==null)return;if(enabled&&!paused&&motion.IsChecked==true&&(effect.SelectedIndex==1||effect.SelectedIndex==3))animation.Start();else animation.Stop();}
    void Reset(){
        SetEnabled(false);SetPaused(false);updating=true;
        method.SelectedIndex=0;effect.SelectedIndex=0;anchor.SelectedIndex=4;monitor.SelectedIndex=0;
        primaryColor=ParseColor("#87CEEB");secondaryColor=Colors.Black;mainHex.Text="#87CEEB";secondaryHex.Text="#000000";mainPreset.SelectedIndex=0;secondaryPreset.SelectedIndex=0;
        footerColor=Colors.Black;footerHex.Text="#000000";
        opacity=0.8;opacitySlider.Value=80;opacityNumber.Text="80";widthPercent=35;heightPercent=18;widthNumber.Text="35";heightNumber.Text="18";
        customX=0;customY=0;xNumber.Text="0";yNumber.Text="0";intensity.Value=55;motion.IsChecked=true;
        foreach(TextBox t in new TextBox[]{mainHex,secondaryHex,footerHex,opacityNumber,widthNumber,heightNumber,xNumber,yNumber}){t.BorderBrush=Brushes.Gray;t.ToolTip=null;}
        updating=false;phase=0;Rebuild();Place();SyncAnimation();status.Text="Safely reset • hidden, default colors, no effect.";
    }
    public void CloseOwned(){if(closing)return;closing=true;if(animation!=null)animation.Stop();if(qaTimer!=null)qaTimer.Stop();if(overlay!=null)overlay.Close();}

    void Check(string name,bool passed,object detail){checks.Add(new Dictionary<string,object>{{"name",name},{"pass",passed},{"detail",detail}});if(!passed)failures++;}
    byte[] Capture(string name){
        overlay.UpdateLayout();int w=Math.Max(1,(int)Math.Ceiling(root.ActualWidth)),h=Math.Max(1,(int)Math.Ceiling(root.ActualHeight));
        var bitmap=new RenderTargetBitmap(w,h,96,96,PixelFormats.Pbgra32);bitmap.Render(root);
        var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(bitmap));
        using(var stream=File.Create(System.IO.Path.Combine(evidence,name+".png")))encoder.Save(stream);
        byte[] pixels=new byte[w*h*4];bitmap.CopyPixels(pixels,w*4,0);return pixels;
    }
    static int AlphaCount(byte[] b){int n=0;for(int i=3;i<b.Length;i+=4)if(b[i]>0)n++;return n;}
    static int OpaqueCount(byte[] b){int n=0;for(int i=3;i<b.Length;i+=4)if(b[i]==255)n++;return n;}
    static int ColorCount(byte[] b,Color c){int n=0;for(int i=0;i<b.Length;i+=4)if(b[i+3]==255&&b[i]==c.B&&b[i+1]==c.G&&b[i+2]==c.R)n++;return n;}
    void CapturePanel(){
        var visual=(FrameworkElement)Panel.Content;visual.UpdateLayout();
        // Evidence-only padding; never resize or capture a foreign window.
        const int margin=20;
        var drawing=new DrawingVisual();
        using(var dc=drawing.RenderOpen()){
            dc.DrawRectangle(Panel.Background,null,new Rect(0,0,visual.ActualWidth+2*margin,visual.ActualHeight+2*margin));
            dc.DrawRectangle(new VisualBrush(visual),null,new Rect(margin,margin,visual.ActualWidth,visual.ActualHeight));
        }
        var bitmap=new RenderTargetBitmap((int)Math.Ceiling(visual.ActualWidth)+2*margin,(int)Math.Ceiling(visual.ActualHeight)+2*margin,96,96,PixelFormats.Pbgra32);bitmap.Render(drawing);
        var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(bitmap));
        using(var stream=File.Create(System.IO.Path.Combine(evidence,"00-controls.png")))encoder.Save(stream);
    }
    static string Hash(byte[] b){using(var sha=SHA256.Create()){return BitConverter.ToString(sha.ComputeHash(b)).Replace("-","").ToLowerInvariant();}}
    void CheckFooter(string methodName){
        var contract=Dict(asset["footer"]);var group=(GeometryGroup)footerInk.Data;
        Check(methodName+" exact pointed footer",(string)contract["text"]==FooterText,contract["text"]);
        Check(methodName+" unpointed final word",((string)contract["text"]).Split(' ')[4]=="מאומן",null);
        int ink=0,vowels=0,vowelPixels=0,letters=0,pointed=0;bool nonempty=true;
        object[] glyphs=Items(layout["footerGlyphs"]);
        for(int i=0;i<glyphs.Length;i++){
            var g=Dict(glyphs[i]);Geometry geometry=group.Children[i];
            nonempty&=!string.IsNullOrEmpty((string)g["path"])&&!geometry.Bounds.IsEmpty&&geometry.GetArea()>0;
            if(geometry.GetArea()>0)ink++;
            int id=Convert.ToInt32(g["glyphId"]);
            if(id==133||id==140||id==141){
                vowels++;Rect bounds=geometry.Bounds;
                for(int j=0;j<glyphs.Length;j++){
                    var letter=Dict(glyphs[j]);int letterId=Convert.ToInt32(letter["glyphId"]);
                    if(letterId!=133&&letterId!=140&&letterId!=141&&Convert.ToInt32(letter["clusterUtf8"])==Convert.ToInt32(g["clusterUtf8"])){
                        Rect lb=group.Children[j].Bounds;double center=(bounds.Left+bounds.Right)/2;
                        if(bounds.Top>lb.Bottom&&center>=lb.Left&&center<=lb.Right)pointed++;
                    }
                }
                // Native ink raster of each actual positioned vowel, independently of letters.
                var drawing=new DrawingVisual();
                using(var dc=drawing.RenderOpen()){
                    dc.PushTransform(new TranslateTransform(2-bounds.X,2-bounds.Y));
                    dc.DrawGeometry(Brushes.Black,null,geometry);dc.Pop();
                }
                int w=(int)Math.Ceiling(bounds.Width)+4,h=(int)Math.Ceiling(bounds.Height)+4;
                var bitmap=new RenderTargetBitmap(w,h,96,96,PixelFormats.Pbgra32);bitmap.Render(drawing);
                byte[] pixels=new byte[w*h*4];bitmap.CopyPixels(pixels,w*4,0);if(AlphaCount(pixels)>0)vowelPixels++;
            }else letters++;
        }
        Check(methodName+" 24 actual footer ink paths",glyphs.Length==24&&ink==24&&nonempty,ink);
        Check(methodName+" 15 letters and 9 vowel ink paths",letters==15&&vowels==9,new int[]{letters,vowels});
        Check(methodName+" all 9 vowels natively rasterize",vowelPixels==9,vowelPixels);
        Check(methodName+" all 9 vowels below correct shaped letter cluster",pointed==9,pointed);
        Rect all=new Rect(0,0,canvas.Width,canvas.Height),f=group.Bounds,p=primary.Data.Bounds;
        Check(methodName+" complete footer ink height exactly 20 percent of primary Name",Math.Abs(f.Height/p.Height-0.20)<0.000001&&Num(layout["footerSizeRatio"])==0.20,new double[]{f.Height,p.Height,f.Height/p.Height});
        Check(methodName+" footer small and not stretched to Name width",f.Width<=canvas.Width*0.9&&group.Children.Count==24,f.Width/canvas.Width);
        Check(methodName+" full Name and footer geometrically fit",all.Contains(p)&&all.Contains(secondary.Data.Bounds)&&all.Contains(f),new string[]{all.ToString(CultureInfo.InvariantCulture),f.ToString(CultureInfo.InvariantCulture)});
        Check(methodName+" footer centered below Name",f.Top>p.Bottom&&Math.Abs((f.Left+f.Right)/2-canvas.Width/2)<0.1,f.ToString(CultureInfo.InvariantCulture));
        Check(methodName+" footer follows overall opacity and fit",canvas.Children.Contains(footerInk)&&view.Child==canvas&&root.Children.Contains(view)&&footerInk.Opacity==1&&view.Stretch==Stretch.Uniform,null);
        Check(methodName+" independent black footer default",footerColor==Colors.Black&&((SolidColorBrush)footerInk.Fill).Color==Colors.Black,null);
    }
    void StartQa(){
        qaTimer=new DispatcherTimer();qaTimer.Interval=TimeSpan.FromMilliseconds(250);
        qaTimer.Tick+=delegate {try{QaStep();}catch(Exception ex){Check("native exception",false,ex.ToString());FinishQa();}};
        qaTimer.Start();
    }
    void QaStep(){
        switch(stage++){
        case 0:
            Check("initially hidden",!enabled&&!overlay.IsVisible,null);
            SetEnabled(true);root.Opacity=1;opacitySlider.Value=100;
            Check("native styles",(Native.GetWindowLong(hwnd,Native.EXSTYLE)&(Native.TRANSPARENT|Native.NOACTIVATE|Native.TOOLWINDOW|Native.LAYERED))==(Native.TRANSPARENT|Native.NOACTIVATE|Native.TOOLWINDOW|Native.LAYERED),Native.GetWindowLong(hwnd,Native.EXSTYLE));
            Check("native topmost",(Native.GetWindowLong(hwnd,Native.EXSTYLE)&8)!=0,overlay.Topmost);
            Check("transparent native WPF surface",overlay.AllowsTransparency&&overlay.Background==Brushes.Transparent&&root.Background==Brushes.Transparent,null);
            Check("hit test click-through",Native.SendMessage(hwnd,0x84,IntPtr.Zero,IntPtr.Zero).ToInt64()==-1,null);
            Check("mouse does not activate",Native.SendMessage(hwnd,0x21,IntPtr.Zero,IntPtr.Zero).ToInt64()==3,null);
            Check("no activation requested",!overlay.ShowActivated&&!overlay.Focusable&&!overlay.ShowInTaskbar,null);
            Check("interleaved primary order",primaryOrder=="יהוה",primaryOrder);
            Check("interleaved secondary order",secondaryOrder=="אדני",secondaryOrder);
            var logical=new StringBuilder();int n=0;bool alternate=true;
            foreach(object item in Items(layout["glyphs"])){var g=Dict(item);logical.Append((string)g["letter"]);alternate&=(string)g["role"]==(n++%2==0?"primary":"secondary");}
            Check("exact interleaved logical order",logical.ToString()=="יאהדונהי"&&alternate,logical.ToString());
            CheckFooter("interleaved");
            break;
        case 1:
            CapturePanel();
            byte[] normal=Capture("01-interleaved");
            Check("actual transparent background pixels",normal[3]==0&&AlphaCount(normal)<normal.Length/4,AlphaCount(normal));
            Check("actual opaque glyph pixels",OpaqueCount(normal)>100,OpaqueCount(normal));
            Check("actual primary sky blue pixels",ColorCount(normal,primaryColor)>30,ColorCount(normal,primaryColor));
            Check("actual secondary black pixels",ColorCount(normal,secondaryColor)>30,ColorCount(normal,secondaryColor));
            opacityNumber.Text="0";break;
        case 2:
            byte[] transparent=Capture("02-zero-opacity");Check("zero opacity has no ink",AlphaCount(transparent)==0,AlphaCount(transparent));
            opacityNumber.Text="100";Check("numeric opacity synchronized",opacitySlider.Value==100&&root.Opacity==1,null);
            opacitySlider.Value=37;Check("slider opacity synchronized",opacityNumber.Text=="37"&&root.Opacity==0.37,null);opacitySlider.Value=100;
            mainHex.Text="#123456";secondaryHex.Text="#BD7722";
            Check("independent hex colors",primaryColor==ParseColor("#123456")&&secondaryColor==ParseColor("#BD7722"),null);
            mainHex.Text="#BADHEX";Check("invalid hex retains last valid",primaryColor==ParseColor("#123456"),mainHex.ToolTip);
            mainPreset.SelectedIndex=0;secondaryPreset.SelectedIndex=0;
            widthNumber.Text="-2";Check("invalid size rejected",widthPercent==35,null);widthNumber.Text="35";
            opacityNumber.Text="101";Check("invalid opacity rejected",opacity==1,null);opacityNumber.Text="100";
            for(int i=0;i<9;i++){anchor.SelectedIndex=i;Place();Rect r=WorkArea();double ex=r.Left+(r.Width-overlay.Width)*(i%3)/2,ey=r.Top+(r.Height-overlay.Height)*(i/3)/2;Check("anchor "+i,Math.Abs(overlay.Left-ex)<0.1&&Math.Abs(overlay.Top-ey)<0.1,new double[]{overlay.Left,overlay.Top});}
            xNumber.Text="41";yNumber.Text="53";anchor.SelectedIndex=9;
            // WPF rounds to device pixels at fractional DPI. Test native placement
            // to one physical pixel rather than demanding impossible DIP equality.
            Native.RECT rect;Native.GetWindowRect(hwnd,out rect);
            Matrix toDevice=PresentationSource.FromVisual(overlay).CompositionTarget.TransformToDevice;
            Point expected=toDevice.Transform(new Point(41,53));
            Check("custom native position (one pixel tolerance)",Math.Abs(rect.Left-expected.X)<=1&&Math.Abs(rect.Top-expected.Y)<=1,new double[]{rect.Left,rect.Top,expected.X,expected.Y});
            Check("native bounds nonempty",rect.Right>rect.Left&&rect.Bottom>rect.Top,new int[]{rect.Left,rect.Top,rect.Right,rect.Bottom});
            anchor.SelectedIndex=4;method.SelectedIndex=1;
            Check("nested primary order",primaryOrder=="יהוה",primaryOrder);Check("nested secondary order",secondaryOrder=="אדני",secondaryOrder);
            var group=(GeometryGroup)secondary.Data;var finalPrimary=((GeometryGroup)primary.Data).Children[3].Bounds;
            bool inside=true;foreach(Geometry g in group.Children)inside&=finalPrimary.Contains(g.Bounds);
            Check("nested inset inside leftmost final letter bounds",inside,finalPrimary.ToString(CultureInfo.InvariantCulture));
            CheckFooter("nested");
            effect.SelectedIndex=0;break;
        case 3:
            Capture("03-nested");effect.SelectedIndex=1;Check("fire geometry mask",object.ReferenceEquals(decoration.Data,primary.Data)&&decoration.Fill is LinearGradientBrush&&secondary.Fill is SolidColorBrush,null);
            Check("fire leaves footer plain black",footerInk.Effect==null&&((SolidColorBrush)footerInk.Fill).Color==Colors.Black,null);break;
        case 4:
            fireBefore=Capture("04-fire-a");Check("animation runs",animation.IsEnabled&&frames>0,frames);break;
        case 5:
            fireAfter=Capture("05-fire-b");Check("fire actually changes rendered pixels",Hash(fireBefore)!=Hash(fireAfter),new string[]{Hash(fireBefore),Hash(fireAfter)});
            Check("fire preserves independent secondary ink",ColorCount(fireAfter,secondaryColor)>5,ColorCount(fireAfter,secondaryColor));
            SetPaused(true);pausedFrames=frames;break;
        case 6:
            Check("pause stops animation",!animation.IsEnabled&&frames==pausedFrames,frames);SetPaused(false);motion.IsChecked=false;pausedFrames=frames;break;
        case 7:
            Check("reduced motion stops animation",!animation.IsEnabled&&frames==pausedFrames,frames);effect.SelectedIndex=2;
            Check("glow transition",primary.Effect is DropShadowEffect&&decoration.Opacity==0,null);Capture("06-glow");effect.SelectedIndex=3;break;
        case 8:
            Capture("07-shimmer");Check("shimmer transition",primary.Effect==null&&decoration.Fill is LinearGradientBrush,null);motion.IsChecked=true;Check("shimmer motion resumes",animation.IsEnabled,null);
            fireBefore=Capture("08-shimmer-a");break;
        case 9:
            fireAfter=Capture("09-shimmer-b");Check("shimmer actually changes rendered pixels",Hash(fireBefore)!=Hash(fireAfter),new string[]{Hash(fireBefore),Hash(fireAfter)});
            effect.SelectedIndex=0;Check("none removes effects and stops motion",primary.Effect==null&&decoration.Opacity==0&&!animation.IsEnabled,null);
            for(int i=0;i<Forms.Screen.AllScreens.Length;i++){monitor.SelectedIndex=i;Place();Rect r=WorkArea();Check("monitor "+i+" sizing",Math.Abs(overlay.Width-r.Width*0.35)<1&&Math.Abs(overlay.Height-r.Height*0.18)<1,new double[]{r.Left,r.Top,r.Width,r.Height});}
            SetEnabled(false);Check("hide stops native visibility and motion",!Native.IsWindowVisible(hwnd)&&!animation.IsEnabled,null);
            Reset();Check("safe reset hidden defaults",!enabled&&effect.SelectedIndex==0&&method.SelectedIndex==0&&primaryColor==ParseColor("#87CEEB")&&secondaryColor==Colors.Black&&opacity==0.8,null);
            Check("reset remains stopped",!animation.IsEnabled,null);
            Check("reset footer black",footerColor==Colors.Black&&footerHex.Text=="#000000",null);break;
        case 10:
            SetEnabled(true);opacitySlider.Value=100;widthNumber.Text="80";heightNumber.Text="60";method.SelectedIndex=0;break;
        case 11:
            Capture("10-large-interleaved");method.SelectedIndex=1;break;
        case 12:
            Capture("11-large-nested");footerHex.Text="#BB1166";
            Check("footer color independent",footerColor==ParseColor("#BB1166")&&primaryColor==ParseColor("#87CEEB")&&secondaryColor==Colors.Black,null);
            footerHex.Text="#BADHEX";Check("invalid footer hex retains last valid",footerColor==ParseColor("#BB1166"),footerHex.ToolTip);
            foreach(int fx in new int[]{1,2,3}){effect.SelectedIndex=fx;Check("effect "+fx+" excludes footer",footerInk.Effect==null&&((SolidColorBrush)footerInk.Fill).Color==footerColor&&!object.ReferenceEquals(decoration.Data,footerInk.Data),null);}
            effect.SelectedIndex=0;break;
        case 13:
            byte[] colored=Capture("12-footer-color");Check("actual independent footer color pixels",ColorCount(colored,footerColor)>100,ColorCount(colored,footerColor));
            Reset();FinishQa();break;
        }
    }
    void FinishQa(){
        qaTimer.Stop();
        CloseOwned();
        Check("native overlay destroyed",!Native.IsWindow(hwnd),null);
        Panel.Close();
        Check("all own windows closed",app.Windows.Count==0,app.Windows.Count);
        ExitCode=failures==0?0:1;
        var receipt=new Dictionary<string,object>{{"schema",1},{"mode","native WPF SelfTest"},{"total",checks.Count},{"passed",checks.Count-failures},{"failed",failures},{"checks",checks},{"frames",frames},{"monitors",MonitorNames()},{"onlyOwnedWindows",true},{"desktopAcceptance","Parent must separately inspect pixels and ordinary-desktop click-through; secure desktop/exclusive fullscreen are not promised."}};
        File.WriteAllText(System.IO.Path.Combine(evidence,"receipt.json"),new JavaScriptSerializer().Serialize(receipt),Encoding.UTF8);
        Console.WriteLine("SELFTEST total="+checks.Count+" passed="+(checks.Count-failures)+" failed="+failures);
        app.Shutdown(ExitCode);
    }
}
}
